package com.example.mohamed.moviesapp;


import android.app.Fragment;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;
import com.example.mohamed.moviesapp.sql_data.DbMethods;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


/**
 * Created by MoHaMeD on 1/04/2016.
 */
public class MainFragment extends Fragment {
    NameListener mListener;
    ArrayList<Movie> movies = new ArrayList<>();
    public GridView gridView;
    DbMethods db;
    ImageView imgFavourite;
    private String select;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View fragment = inflater.inflate(R.layout.gridview_layout, container, false);
        gridView = (GridView) fragment.findViewById(R.id.grid_view);

        imgFavourite = (ImageView) fragment.findViewById(R.id.imgFavourite);

        select = getArguments().getString("select", "top_rated");
        db = new DbMethods(getActivity());
        ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(getActivity().CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
        if (isConnected) {
            try {

                if (select.equals("most_popular")) {
                    new GetMostPopularMovies().execute();
                    movies.clear();
                } else if (select.equals("top_rated")) {
                    new GetTopRatedMovies().execute();
                    movies.clear();
                } else if (select.equals("Favourite")) {
                    Intent intent = new Intent(getActivity(), FavouriteActivity.class);
                    startActivity(intent);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    Intent details = new Intent(getActivity(), MainDetails.class);
                    details.putExtra("Key", movies.get(position));
                    startActivity(details);
                }
            });
        } else {
            Toast.makeText(getActivity(), "There Is No Internet Connection , Please Check It .", Toast.LENGTH_LONG).show();
        }


        return fragment;
    }

    public void setNameListener(NameListener nameListener) {
        this.mListener = nameListener;
    }

    //Get Top Rated Movies From The Url
    private class GetTopRatedMovies extends AsyncTask<Void, ArrayList<Movie>, String> {

        //        ArrayList<Movie> movies = new ArrayList<>();
        @Override
        protected String doInBackground(Void... params) {

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            // Will contain the raw JSON response as a string.
            String forecastJsonStr = null;
            try {

                // Construct the URL for the OpenWeatherMap query
                // Possible parameters are avaiable at OWM's forecast API page, at
                // http://openweathermap.org/API#forecast
                URL url = new URL("http://api.themoviedb.org/3/movie/top_rated?api_key=");

                // Create the request to OpenWeatherMap, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                    // But it does make debugging a *lot* easier if you print out the completed
                    // buffer for debugging.
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                forecastJsonStr = buffer.toString();
                return forecastJsonStr;
            } catch (IOException e) {
                Log.e("PlaceholderFragment", "Error ", e);
                // If the code didn't successfully get the weather data, there's no point in attemping
                // to parse it.
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e("PlaceholderFragment", "Error closing stream", e);
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {

                JSONObject jsonObject = new JSONObject(s);
                JSONArray jsonArray = new JSONArray(jsonObject.getString("results"));

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj2 = jsonArray.getJSONObject(i);
                    Movie movie = new Movie();

                    movie.setId(obj2.getString("id"));
                    movie.setOriginal_title(obj2.getString("original_title"));
                    movie.setOverview(obj2.getString("overview"));
                    movie.setRelease_date(obj2.getString("release_date"));
                    movie.setPoster_path(obj2.getString("poster_path"));
                    movie.setVote_average(obj2.getString("vote_average"));
                    movies.add(movie);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            gridView.setAdapter(new MainAdapter(getActivity(), movies));
            Log.i("json", s);

        }
    }

    //Get Most Popular Movies From The Url
    private class GetMostPopularMovies extends AsyncTask<Void, ArrayList<Movie>, String> {
        @Override
        protected String doInBackground(Void... params) {

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            // Will contain the raw JSON response as a string.
            String forecastJsonStr = null;
            try {

                URL url = new URL("http://api.themoviedb.org/3/movie/popular?api_key=");

                // Create the request to OpenWeatherMap, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                    // But it does make debugging a *lot* easier if you print out the completed
                    // buffer for debugging.
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                forecastJsonStr = buffer.toString();
                return forecastJsonStr;
            } catch (IOException e) {
                Log.e("PlaceholderFragment", "Error ", e);
                // If the code didn't successfully get the weather data, there's no point in attemping
                // to parse it.
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e("PlaceholderFragment", "Error closing stream", e);
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {

                JSONObject jsonObject = new JSONObject(s);
                JSONArray jsonArray = new JSONArray(jsonObject.getString("results"));

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj2 = jsonArray.getJSONObject(i);
                    Movie movie = new Movie();
                    movie.setId(obj2.getString("id"));
                    movie.setOriginal_title(obj2.getString("original_title"));
                    movie.setOverview(obj2.getString("overview"));
                    movie.setRelease_date(obj2.getString("release_date"));
                    movie.setPoster_path(obj2.getString("poster_path"));
                    movie.setVote_average(obj2.getString("vote_average"));
                    movies.add(movie);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            gridView.setAdapter(new MainAdapter(getActivity(), movies));
            Log.i("json", s);

        }
    }

}
