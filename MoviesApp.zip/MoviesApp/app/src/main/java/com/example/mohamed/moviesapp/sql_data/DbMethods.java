package com.example.mohamed.moviesapp.sql_data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.mohamed.moviesapp.Movie;

import java.util.ArrayList;


public class DbMethods {

	SqlHelper helper;
	SQLiteDatabase db;

	public DbMethods(Context context) {
		helper = new SqlHelper(context);
		db = helper.getWritableDatabase();
	}

	public long FavouriteMovies(Movie movie) {
		long id = 0;
		ContentValues contentValues = new ContentValues();
		contentValues.put(SqlHelper.id, movie.getId());
		contentValues.put(SqlHelper.original_title, movie.getOriginal_title());
		contentValues.put(SqlHelper.poster_path, movie.getPoster_path());
		contentValues.put(SqlHelper.overview, movie.getOverview());
		contentValues.put(SqlHelper.release_date, movie.getRelease_date());
		id = db.insert(SqlHelper.Table_Name, null, contentValues);
		return id;
	}


	public ArrayList<String> getPosters() {

		ArrayList<String> poster_path = new ArrayList<>();
		String[] columns = { SqlHelper.poster_path };
		Cursor cursor = db.query(SqlHelper.Table_Name, columns, null, null, null,
				null, null);
		while (cursor.moveToNext()) {
			poster_path.add(cursor.getString(0));
		}
		return poster_path;
	}

	public ArrayList<String> getTitles() {

		ArrayList<String> Titles = new ArrayList<>();
		String[] columns = { SqlHelper.original_title };
		Cursor cursor = db.query(SqlHelper.Table_Name, columns, null, null, null,
				null, null);
		while (cursor.moveToNext()) {
			Titles.add(cursor.getString(0));
		}
		return Titles;
	}

	public ArrayList<Integer> getIds() {

		ArrayList<Integer> Ids = new ArrayList<>();
		String[] columns = { SqlHelper.id };
		Cursor cursor = db.query(SqlHelper.Table_Name, columns, null, null, null,
				null, null);
		while (cursor.moveToNext()) {
			Ids.add(cursor.getInt(0));
		}
		return Ids;
	}

	public int removeFavourite(Movie movie){
		return db.delete(SqlHelper.Table_Name," id = ? ",new String[] { movie.getId()+"" });
	}
}
