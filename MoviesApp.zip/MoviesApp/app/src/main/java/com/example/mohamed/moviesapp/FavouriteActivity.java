package com.example.mohamed.moviesapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.GridView;

import com.example.mohamed.moviesapp.sql_data.DbMethods;


public class FavouriteActivity extends AppCompatActivity {

    GridView gridFavourite;
    DbMethods db; // object db
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);
        Toolbar toolbar = (Toolbar) findViewById(R.id.appbar);
        setSupportActionBar(toolbar);
        //---------------//
        db=new DbMethods(this);
        //-----------------//
        gridFavourite = (GridView) findViewById(R.id.gridaFvourite);
        gridFavourite.setAdapter(new FavouriteAdapter(db.getTitles(),db.getPosters(),this));
    }

}
