package com.example.mohamed.moviesapp;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class FavouriteAdapter extends BaseAdapter {

    ArrayList<String> titles;
    ArrayList<String> posters;
    Context context;
    LayoutInflater inflater;

    public FavouriteAdapter(ArrayList<String> titles, ArrayList<String> posters, Context context){
        this.titles=titles;
        this.posters=posters;
        this.context=context;
    }

    @Override
    public int getCount() {
        return titles.size();
    }

    @Override
    public Object getItem(int position) {
        return titles.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view=convertView;
        if (view == null) {
            inflater = (LayoutInflater) parent.getContext()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.grid_favourite, null);
        } else {
            view = convertView;
        }

        ImageView imPoster=(ImageView) view.findViewById(R.id.imageFavorit);
        TextView imTitle=(TextView) view.findViewById(R.id.textTitel);
        Picasso.with(context)
                .load("http://image.tmdb.org/t/p/w185"+posters.get(position))
                .into(imPoster);
        imTitle.setText(titles.get(position));

        return view;
    }
}
