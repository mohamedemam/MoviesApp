package com.example.mohamed.moviesapp;

/**
 * Created by Sabry Saad on 3/27/2016.
 */


public class NavItem {

    private String title;
    private int icon;

    public NavItem(String title, int icon){
        this.title = title;
        this.icon = icon;
    }

    public String getTitle(){
        return this.title;
    }

    public int getIcon(){
        return this.icon;
    }
}