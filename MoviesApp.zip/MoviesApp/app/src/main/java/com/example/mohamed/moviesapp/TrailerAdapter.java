package com.example.mohamed.moviesapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;

/**
 * Created by MoHaMeD on 29/04/2016.
 */
public class TrailerAdapter extends BaseAdapter {
    LayoutInflater inflater;
    private Context sContext;
    ArrayList<String> trailers;

    public TrailerAdapter(ArrayList<String> trailers, Context context) {
        this.trailers = trailers;
        sContext = context;
    }

    @Override
    public int getCount() {
        return trailers.size();
    }

    @Override
    public Object getItem(int position) {
        return trailers.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        inflater = (LayoutInflater) parent.getContext()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ImageView imageView = new ImageView(sContext);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new GridView.LayoutParams(200, 200));
        view = inflater.inflate(R.layout.list_item_trails, null);
        imageView = (ImageView) view.findViewById(R.id.imgmeno);
//        final String url = "https://www.youtube.com/watch?v=" + trailers.get(position).toString();
        return imageView;

    }
}
