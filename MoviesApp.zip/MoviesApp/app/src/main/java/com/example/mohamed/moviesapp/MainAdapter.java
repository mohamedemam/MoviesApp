package com.example.mohamed.moviesapp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by MoHaMeD on 1/04/2016.
 */
public class MainAdapter extends BaseAdapter {

    private Context mainContext;
    ArrayList<Movie> mainmovies;

    public MainAdapter(Context context, ArrayList<Movie> movies) {
        mainmovies = movies;
        mainContext = context;
    }

    @Override
    public int getCount() {
        return mainmovies.size();
    }

    @Override
    public Object getItem(int position) {
        return mainmovies.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView = new ImageView(mainContext);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new GridView.LayoutParams(200, 200));

        try {
            Picasso.with(mainContext).load("http://image.tmdb.org/t/p/w185/" + mainmovies.get(position).getPoster_path()).into(imageView);
        } catch (Exception e) {
            Toast.makeText(mainContext, "  mfish net ", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        return imageView;
    }
}
