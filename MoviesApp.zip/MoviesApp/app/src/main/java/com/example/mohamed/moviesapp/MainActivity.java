package com.example.mohamed.moviesapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.FrameLayout;


/**
 * Created by MoHaMeD on 1/04/2016.
 */
public class MainActivity extends AppCompatActivity implements NameListener {

    boolean mTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.appbar);
        setSupportActionBar(toolbar);


        FrameLayout flPanel2 = (FrameLayout) findViewById(R.id.frag_two);
        if (null == flPanel2) {
            mTwoPane = false;
        } else {
            mTwoPane = true;
        }

        if (null == savedInstanceState) {
            Bundle sorting = new Bundle();
            sorting.putString("select", "top_rated");
            MainFragment mainFragment = new MainFragment();
            mainFragment.setArguments(sorting);
            mainFragment.setNameListener(MainActivity.this);
            getFragmentManager().beginTransaction().replace
                    (R.id.main_frag, mainFragment).commit();
        }
    }

    @Override
    public void setSelectedName(Movie name) {
        //Case Two Pane UI
        if (mTwoPane) {
            DetailsFragment detailsFragment = new DetailsFragment();
            Bundle extras = new Bundle();
            extras.putSerializable("selected_movie", name);
            detailsFragment.setArguments(extras);
            getFragmentManager().beginTransaction().replace(R.id.frag_two, detailsFragment).commit();
        } else {
            Intent i = new Intent(this, MainDetails.class);
            i.putExtra("selected_movie", name);
            startActivity(i);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.top_rated) {
            Bundle select = new Bundle();
            select.putString("select", "most_popular");
            MainFragment mainFragment = new MainFragment();
            mainFragment.setArguments(select);
            mainFragment.setNameListener(MainActivity.this);
            getFragmentManager().beginTransaction().replace
                    (R.id.main_frag, mainFragment).commit();

        } else if (id == R.id.most_popular) {
            Bundle select = new Bundle();
            select.putString("select", "top_rated");
            MainFragment mainFragment = new MainFragment();
            mainFragment.setArguments(select);
            mainFragment.setNameListener(MainActivity.this);
            getFragmentManager().beginTransaction().replace
                    (R.id.main_frag, mainFragment).commit();
        } else if (id == R.id.Favourite) {
            Intent intent = new Intent(getApplicationContext(), FavouriteActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }


}
