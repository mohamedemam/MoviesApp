package com.example.mohamed.moviesapp;


import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mohamed.moviesapp.sql_data.DbMethods;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


/**
 * Created by MoHaMeD on 1/04/2016.
 */
public class DetailsFragment extends Fragment {

    TextView tvTitle, tvDate, tvVote, tvOverview;
    ImageView imgPoster, imgFavourite;
    Movie movie;
    int flag = 0;
    ArrayList<String> trailers;

    DbMethods db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View fragment = inflater.inflate(R.layout.activity_details, container, false);
        db = new DbMethods(getActivity());
        tvTitle = (TextView) fragment.findViewById(R.id.tvTitle);
        tvDate = (TextView) fragment.findViewById(R.id.tvDate);
        tvVote = (TextView) fragment.findViewById(R.id.tvVote);
        tvOverview = (TextView) fragment.findViewById(R.id.tvOverview);

        imgPoster = (ImageView) fragment.findViewById(R.id.imgPoster);
        imgFavourite = (ImageView) fragment.findViewById(R.id.imgFavourite);

        Intent details = getActivity().getIntent();
        movie = (Movie) details.getSerializableExtra("Key");

        tvTitle.setText(movie.getOriginal_title());
        tvDate.setText(movie.getRelease_date());
        tvVote.setText(movie.getVote_average());
        tvOverview.setText(movie.getOverview());
        imgPoster.setAdjustViewBounds(true);


        try {
            Picasso.with(getActivity()).load("http://image.tmdb.org/t/p/w185/" + movie.getPoster_path()).into(imgPoster);
        } catch (Exception e) {
            Toast.makeText(getActivity(), "There Is No Internet Connection , Please Check It .", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        new GetMoviesTrailers().execute(movie.getId());
        imgFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (flag == 0) {
                    imgFavourite.setImageResource(android.R.drawable.star_big_on);
                    flag = 1;
                    db.FavouriteMovies(movie);
                } else {
                    imgFavourite.setImageResource(android.R.drawable.star_big_off);
                    flag = 0;
                    db.removeFavourite(movie);
                }

            }
        });
        return fragment;
    }

    private class GetMoviesTrailers extends AsyncTask<String, Void, ArrayList<String>> {

        String jsonOutput;
        JSONObject jsonObject = null;
        int Size;
        ArrayList<String> VideoPath = new ArrayList<>();

        @Override
        protected ArrayList<String> doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;


            // Will contain the raw JSON response as a string.
            String trailsJsonStr = null;

            try {
                //  the URL for the moviedb
                String baseUrl = "http://api.themoviedb.org/3/movie/" + params[0] + "/videos?api_key=";
                URL url = new URL(baseUrl);

                // Create the request  to open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }
                if (buffer.length() == 0) {
                    return null;
                }
                trailsJsonStr = buffer.toString();
            } catch (IOException e) {
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        //   Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }

            jsonOutput = new String(trailsJsonStr);
            try {
                jsonObject = new JSONObject(jsonOutput);
                JSONArray jsonArray = jsonObject.getJSONArray("results");
                Size = jsonArray.length();
                String[] tempArray = new String[Size];
                for (int i = 0; i < Size; i++) {
                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                    VideoPath.add(jsonObject1.getString("key"));
                    Log.e("doInBackground: ", jsonObject1.getString("key"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return VideoPath;
        }

        @Override
        protected void onPostExecute(ArrayList<String> arrTrailers) {
            super.onPostExecute(arrTrailers);
            trailers = arrTrailers;
            ArrayList<NavItem> spinnerNavItemsarraylist = new ArrayList<>();
            for (int i = 0; i < trailers.size(); i++) {
                spinnerNavItemsarraylist.add(new NavItem(trailers.get(i), R.mipmap.ic_launcher));
            }

            ListView listView = (ListView) getActivity().findViewById(R.id.TrailLink);
            listView.setAdapter(new TrailerAdapter(trailers, getActivity()));

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    final String url = "https://www.youtube.com/watch?v=" + trailers.get(position).toString();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            });

        }
    }

}
