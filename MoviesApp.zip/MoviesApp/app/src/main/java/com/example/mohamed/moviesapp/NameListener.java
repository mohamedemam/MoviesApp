package com.example.mohamed.moviesapp;


/**
 * Created by MoHaMeD on 1/04/2016.
 */
public interface NameListener {
    public void setSelectedName(Movie movie);
}
